from __future__ import division
import math
import utils
import copy
def Boxing(NEPvm,Pvm,N_Pvm,CPU_kernal,CPU_memory,condition):
    VMs=[]
    # all Predicted vms
    for i in range(N_Pvm):
        for j in range(int(NEPvm[i])):
            VMs.append(Pvm[i])
    lenVMs=len(VMs) # The number of all predicted VMs
    print lenVMs
    # Split vms according to M/K
    VM1=[];
    VM2=[];
    VM4=[];
    for i in range(lenVMs):
        VMs_info=[VMs[i][1],VMs[i][2]]
        if (VMs_info[1]/VMs_info[0]==1):
            VM1.append(VMs[i])
        elif(VMs_info[1]/VMs_info[0]==2):
            VM2.append(VMs[i])
        else:
            VM4.append(VMs[i])
    VMs=[] #reset
    if(condition==0):
        VM4=Adjust(VM4,0)
        VM2=Adjust(VM2,0)
        VM1=Adjust(VM1,0)
        T_VMs=[VM4,VM2,VM1]
        len4=len(VM4)+1
        len2=len(VM2)+1
        len1=len(VM1)+1
        #maybe exist zero
        for i in range(lenVMs):
            TEMP=[(len(T_VMs[0])/len4),(len(T_VMs[1])/len2),(len(T_VMs[2])/len1)]
            M=TEMP.index(max(TEMP))
            if(len(T_VMs[M])!=0):
                VMs.append(T_VMs[M][0])
                (T_VMs[M]).remove(T_VMs[M][0])
        print len(VMs)

    CPU=[]
    CPU.append([])
    N_PCPU=0   #default 0
    VMSC=copy.deepcopy(VMs)
    while(1):
        CPU_limit=[CPU_kernal,CPU_memory]
        lenVM=len(VMs)
        for j in range(lenVM):
            VMs_info=[VMs[j][1],VMs[j][2]]
            if(CPU_limit[0]>=VMs_info[0] and CPU_limit[1]>=VMs_info[1]):
                CPU[N_PCPU].append(VMs[j][0])
                CPU_limit[0]=CPU_limit[0]-VMs_info[0]
                CPU_limit[1]=CPU_limit[1]-VMs_info[1]
                VMSC.remove(VMs[j])
        if(utils.SUM_Judge(VMSC,CPU_kernal,CPU_memory)):
            break
        else:
            VMs=copy.deepcopy(VMSC)
            CPU.append([])
            N_PCPU=N_PCPU+1 
    return CPU,(N_PCPU+1)
        
def Adjust(VM,condition):
    idx=Cond_Sort(VM,0)
    T=[]
    for i in range(len(VM)):
        T.append(VM[idx[i]])
    VM=T
    return VM
def Cond_Sort(VM,condition):
    T_VM=[]
    if(condition==0):
        for i in range(len(VM)):
            T_VM.append(VM[i][1])
        idx=utils.argsort(T_VM)
        return idx
    else:
        for i in range(len(VM)):
            T_VM.append(VM[i][2])
        idx=utils.argsort(T_VM)
        return idx
