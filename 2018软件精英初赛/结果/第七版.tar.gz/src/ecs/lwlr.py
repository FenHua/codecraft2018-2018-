import math
import utils
import NLRegress
def lwlr(testPoint,xArr,yArr,k=3):
    # locally weighted linear regression
    xMat=xArr
    yMat=yArr
    m=len(xMat)
    result=0
    weights=[1 for i in range(m)]
    diffMat=[0 for i in range(m)]
    for j in range(m):
        diffMat[j]=testPoint-xMat[j]
        weights[j]=math.exp(diffMat[j]**2/(-2.0*(k**2)))
    for i in range(m):
        result=result+weights[i]*yArr[i]
    #print result
    return result

def lwlr_predict(N_Pvm,lenD,S_Data,Predict_time):
    k=4.4
    xArr=[i for i in range(lenD)]
    yArr=[]
    for i in range(N_Pvm):
        yArr.append(S_Data[i])
    testArr=[j for j in range(lenD,(lenD+Predict_time),1)]
    NEPvm=[0 for i in range(N_Pvm)]   
    for i in range(N_Pvm):
        T=0
        for j in range(Predict_time):
            T=T+lwlr(testArr[j],xArr,yArr[i],k)
        NEPvm[i]=int(math.ceil(T))
    return NEPvm

def Prob_predict(N_Pvm,Len_History,S_Data,Predict_time):
    Probablity=[0 for i in range(N_Pvm)]
    for i in range(N_Pvm):
        for j in range(Len_History):
            Probablity[i]=Probablity[i]+S_Data[i][j]
    NEPvm=[math.ceil(Probablity[i]*Predict_time/Len_History) for i in range(N_Pvm)]
    return NEPvm

'''
def EachD_predict(date,start_Hdate,VM,Len_History,S_Data):
    week=utils.iden_week(date)
    Hweek=utils.iden_week(start_Hdate)

    linar_number=0
    
    #intialize list of week
    CD_week=[]
    for i in range(7):
        CD_week.append([])
    
    # split history data according to week
    for i in range(Len_History):
        time=(Hweek+i)%7
        (CD_week[time]).append(S_Data[VM][i])
    if(week==0):
        #monday
    elif(week==1):
        #tueseday
    elif(week==2):
        #wednesday
    elif(week==3):
        #thursday
    elif(week==4):
        #friday
    elif(week==5):
        #saturday
    else:
        #sunday
    return linar_number
'''

def Simp_regress(N_Pvm,lenD,S_Data,Predict_time):
    xdata=[i for i in range(lenD)]
    NEPvm=[0 for i in range(N_Pvm)]
    T_Data=[0 for t in range(7)]
    T_Day=[i for i in range(7)]
    for i in range(N_Pvm):
        for t in range(7):
            T_Data[t]=S_Data[i][t+lenD-7]
        
        [a1,a2,a3]=NLRegress.Leastsq(T_Day,T_Data,7)
        
        for j in range(7,7+Predict_time,1):
            N=a3*(j**2)+a2*j+a3
            if(N>=0):
                NEPvm[i]=NEPvm[i]+N
        if(NEPvm[i]>1.5*max(S_Data[i])):
            NEPvm[i]=math.ceil(1.5*max(S_Data[i]))
        else:
            NEPvm[i]=math.ceil(NEPvm[i])
    return NEPvm
















